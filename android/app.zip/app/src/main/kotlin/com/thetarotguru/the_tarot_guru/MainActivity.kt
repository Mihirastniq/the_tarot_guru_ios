package com.thetarotguru.the_tarot_guru

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
